                                     ===================================================
                                     |                 MBR Regenerator                 |
                                     |                                                 |
                                     |        Developed by Josh Cell Softwares         |
                                     |                                                 |
                                     |              joshcellsoftwares.com              |
                                     ===================================================

About the Software:

	MBR Regenerator, is a technology, to repair any system with bricked files caused by malware or other malicious programs
	who were able to damage the Activation System and Technologies, restoring the windows as a Fresh Install without format
	the or lose any file

	Core files mods [ shell32.dll, uxtheme.dll, explorer.exe ] and others, can cause your system fails to function properly

	With MBR Regeneration System Technology, you is able to repair completely your OS without any brick

	Equipped with injection systems process, MBR Regenerator make a trusted restoration in your system with maximum
	security

Features:

	Will repair, recovery, and restore all activation system, restoring the Windows Activation Technologies [ KB971033 ] to
	original state, install trial key, and able to clean boot code, rebuild tokens for full activation reset factory

	If you don't want to restore the activation, simply uncheck the "Regenerate all activation system" option, the
	regeneration system not touch on this module, any will try repair all files stored on the System32 / SysWOW64, including
	all activation system, rebuilding and repairing activation data

	You also clean the activation system for factory trusted repair, using Advanced Tokens Manager [ by Josh Cell Softwares ]
	to backup your activation before run regeneration system

	Your system, after restart, return untouched on the System32, Activation System, and you can use your system normally, as
	Pre-Installed

	
Operating System Compatibility:

	Windows 7 Ultimate
	Windows 7 Ultimate E
	Windows 7 Ultimate N
	Windows 7 Professional
	Windows 7 Professional E
	Windows 7 Professional N
	Windows 7 Home Premium
	Windows 7 Home Premium E
	Windows 7 Home Premium N
	Windows 7 Home Basic
	Windows 7 Home Basic E
	Windows 7 Home Basic N
	Windows 7 Starter
	Windows 7 Starter E
	Windows 7 Starter N
	Windows 7 Enterprise
	Windows 7 Enterprise E
	Windows 7 Enterprise N
	Windows Embedded Standard 7

	
How to trust a third-party software?

	This is software is developed by Josh Cell Softwares, tested by Softpedia Labs with high management security system analysis,
	without any malicious code:

	http://www.softpedia.com/progClean/MBR-Regenerator-Clean-197128.html

	This is a virus scan of MBR Regenerator v4.5.exe

	http://www.virustotal.com/file-scan/report.html?id=78729c8e1d3dcc6c70445016e36eb07d79d87033eb124598363038b7d001769f-1317060188
	
		File name: MBR Regenerator v4.5.exe
		Submission date: 2011-09-26 18:03:08 (UTC)
		Current status: finished
		Result: 0/ 44 (0.0%)


Hashs for MBR Regenerator v4.5.exe

	CRC32: 9850D740
	MD5: FCA2AA6D8039DD107AFF1A3CFBE97F7B
	SHA-1: 7D47EB1EC59C3381CED53AF2AFE4A5C14CDF86F5


Credits:

	MDL Forums - For supporting this project
	dre022392 - For help with new scripts

	

		"All work is done and needed in the future", Michel Oliveira - Programmer of all JC.Softwares projects


			Email for contact: support@joshcellsoftwares.com

			WebSite: http://www.joshcellsoftwares.com/

			All Forums Support: http://forums.mydigitallife.info/members/197238-Josh-Cell

			This is program not use any external other programs to work with all functions

			Any hard programming developement, and design


					Copyright 2011 Josh Cell Softwares, All Rights Reserved


v4.5

- MBR Regenerator will be fix all activation problems, and all Windows problems related a corrupted files
- Added MBR Regeneration System in the modules, all regeneration technologies is provided by him
- Dll Injection + 15 modules for Factory Clean the activation system is added
- Added MBR Regenerator console application into UI
- MBR Regenerator is able to recover any system
- Using internal function to replace bootloader
- MBR Regenerator now clean infected boot code
- Totally Reworked GUI and core code
- Fixed all bugs
- And more ...

v4.4

- Added "MUIREPAIR" module, 99% fixed slui activation blocks for modified MUI files, enabling forced instalation of the Key and Cert normally, activating system with success
- Optimized GUI and Interface response
- Removed activation backup module
- Totally fixed the GUI bugs
- Optimized main code
- Stable version


v4.3

- Added new method of Boot Sector Rebuilder, automated scanning the hidden system partition, and aplying changes, without affecting GRUB or BOOTCAMP sectors
- Added "Rearm to 30 days" option
- Changed font ot Segoe UI
- Solved small bugs
- Improved Code
- Updated GUI


v4.2

- Improved Code
- Updated GUI


v4.1

- Added Tokens / Pkeyconfig rebuild option, What will create rebuilded tokens as if it were pre-installed
- Updated SFC dll Injection on console code
- Updated GUI, The appearance is cleaner
- Reduced to 0 AV false positive's
- Security features reworked
- Other fixes in the code


v4.0

- Reworked GUI
- Added Options tab
- Added Security Features
- Added silent icon-reload
- Improved activation backup
- Added message box informations
- Optimized code, the program is more lighter
- Fixed Activation Status bug in some systems
- RegQuery arguments is loaded before program starts
- Added automatic SFC dll injection for force SFC works if need


v3.9.3

- Added Windows Embedded Standard 7 Support
- Added Progressbar animated function
- Improved all code
- Updated GUI


v3.9.2

- Added Serial and Activation Status GUI Module
- Added Dynamic version search module, to optimize the application
- Added Activation backup Module, Program now saves key / tokens.dat backup in the C:\ACTIVATION.BAK for new activation
- Added SFC Scanner console, the Close Button of SFC is disabled for security
- Added RegFix for Black Wallpaper, Will fix the registry entries
- Other Fixes in the code


v3.9.1

- Added Force detect module for Uninstall all Slic Driver Injection if installed
- Added Tokens/Cert repair module, for fix activation errors
- Added SFC Freeze module, If you lose power / reset, while sfc is running, no files are corrupted, and your system becomes partially regenerated, is recommended to run again on next boot
- Added more bcdedit commands, Thanks for dre022392
- Added auto-reset on next reboot, after regeneration, ingnore non genuine messages
- Refined GUI, the Close button is hidden when the application is working
- Reworked code


v3.9

- Updated GUI
- Added activation services repair module
- Added KB971033 freeze repair module
- Added rebuild activation repair module
- Added .vbs associations repair module
- Added trial key activation, to fix black desktop at restart
- Hosts file is now cleaned and not replaced as in other versions


v3.8

- Removed by sFix anemeros; is a great tool
- Added automated retrieval of files essential for activation and recovery of the SFC (which was sFix)
- The program can run up to 2x faster, because you no longer have to scan the needed files
- Fixed "ghosting" that crashed program when the machine is slow


v3.7

- Updated GUI
- Added patch to try to fix problems with sfc
- Fixed problems with filecheck
- Fixed problem with access denied
- Fixed problem with replace the HOSTS file


v3.6

- New injection method of required files, completely safe and effective, generating macro-dependency files, which will link to the other using a temporary folder
- Now the application will run very faster, all dependencies were incorporated, single executable is optimizated
- Now, cleaner temp files autimaticaly at exits
- Added file and dependencies check, if archive is corrupt, dont brick the system for missing files
- Updated GUI
- Added platform detection performed
- Fixed bug that crashed the app after clicking on the Progress Bar
- Fixed bug that occurred when opening two instances of the application
- Added update button, which when clicked, will come to the official thread of the application
- Added Messagebox, press ok to restart
- Optimized size and false-positive detections
- Other bugs fixed


v3.5

- Fixed inumerous crashes and multiple errors, now is built in C#
- Code completely redesigned
- Application optimized for x64 systems
- Totally friendly interface, and intuitive
- Fixed problem with black desktop on restart
- Fixed problem not reset after the system restarts
- Fixed crash in sfc, caused by a very file that is automatically restored on systems with problem
- Fixed core files to default permissions
- Stowed time to restore = 10 minutes
- Hybrid application, you only need. NET Framework v3.5 installed


v3.0

- Completely recompiled code for C + +
- Used system injection method, it runs a lot faster
- The SFC scan is now visible in the program
- The program is a hybrid, does not need to run dependencies, making the likelihood of near-zero errors
- The application still remains with a small size
- Tested several times with various versions of Windows 7
- All fixes from previous versions have been enhanced in this version and recompiled
- New icon


v2.2

- View your Pkey incorporated into the program
- Added hosts file backup to .OLD
- Now the main icon is displayed at run
- Fixed bug in final messagebox
- Fixed Other internal changes


v2.1

- Added some commands that will correct problems with permissions on files in the SYSTEM32\WAT & SYSTEM32, which prevent the validation of removewat installed
- Correction of wat services is added 
- Fixed test mode nag on system reboots
- Fixed some validation errors with IE
- Thanks dre022392@MDL for several reports and tips


v2.0

- Added Sfix by anemeros
- SFC Scanner freeze bug solved
- Sfix now is used to restore sfc and slmgr files from the winsxs folder saving space
- Explorer.exe is closed on procedure is working
- Detection of the operating system running and architeture was very well optimized and is much safer
- After finishing the procedure, there is a msgbox asking press ok to restart
- Size is very optimized
- SFC Scanner is now visible
- Fixed some bugs that I could detect, tested many times, and really is very stable


v1.9

- Fixed detection of the enterprise edition, thanks for reporting.
- Improved detection of system architecture / admin manifest error
- Now you need only one reboot
- Recovery of files added
- Cache drive moves to temp, enhanced and refined
- Cache files are deleted after you close the program
- The program is faster and more stable, compatible with the aero
- Size optimized
- Other bugs fixed with the joint in one reboot


v1.8

- Now you need only one reboot
- Recovery of files added
- Cache drive moves to temp, enhanced and refined
- Cache files are deleted after you close the program
- The program is faster and more stable, compatible with the aero
- Size optimized
- Other bugs fixed with the joint in one reboot


v1.7

- Added better compatibility with systems E / N
- Improved graphics, the characters now match the look of the front
- Fixed bug that occurred with the conventional batch language
- Code optimized and improved for a faster run.


v1.6

- Added detection of the operating system running
- Cache changed to optimize and streamline the functioning of the same
- Improved code, and fixed errors


v1.5

- Fixed freezes and the commands takeownership icacls on 64 bit systems
- Fixed bug that did not start the program after the first reboot
- Fixed code and other improvements


v1.4

- Added auto-detection of operating platform
- Added the function status system that shows the activation status among other information
- Auto-detect the version of OS, enhanced, and improved
- Fixed failure to copy files SFC / Host
- Fixed bug SFC Scanner, which prevented the correction by the run
- Fixed crash in command ICACLS when there is a space in your account windows
- Fixed crash in command TAKEOWNERSHIP


v1.3

- Optimized code
- Removed installation of KB971033
- Size optimized
- Added to the maintenance of SFC and HOST files
- New way to run SFC
- Kill services that can disrupt the functioning
- New method of detecting OS


v1.2

- Optimized code
- Service Pack 1 is compatible
- WatFix removed, sorry Daz, your tool is excellent
- Improved compatibility with antivirus
- Improved interface
- Auto-detection platform off, it caused errors on some systems


v1.1

- New interface
- Added compatibility with X64 systems
- Added detection of the operating system and platform
- Added Admin Manifest for a better functioning
- Several fixes and improvements not mentioned gifts


v1.0

Unpublished version.